﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.botapagar = New System.Windows.Forms.Button()
        Me.botdividir = New System.Windows.Forms.Button()
        Me.botmulti = New System.Windows.Forms.Button()
        Me.botsub = New System.Windows.Forms.Button()
        Me.botsoma = New System.Windows.Forms.Button()
        Me.botresult = New System.Windows.Forms.Button()
        Me.bot0 = New System.Windows.Forms.Button()
        Me.bot1 = New System.Windows.Forms.Button()
        Me.bot2 = New System.Windows.Forms.Button()
        Me.bot3 = New System.Windows.Forms.Button()
        Me.bot4 = New System.Windows.Forms.Button()
        Me.bot5 = New System.Windows.Forms.Button()
        Me.bot6 = New System.Windows.Forms.Button()
        Me.bot7 = New System.Windows.Forms.Button()
        Me.bot8 = New System.Windows.Forms.Button()
        Me.bot9 = New System.Windows.Forms.Button()
        Me.Resultado = New System.Windows.Forms.TextBox()
        Me.TextNum1 = New System.Windows.Forms.TextBox()
        Me.TxtOp = New System.Windows.Forms.TextBox()
        Me.botClean = New System.Windows.Forms.Button()
        Me.botInverter = New System.Windows.Forms.Button()
        Me.botPonto = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'botapagar
        '
        Me.botapagar.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.botapagar.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.botapagar.Location = New System.Drawing.Point(12, 385)
        Me.botapagar.Name = "botapagar"
        Me.botapagar.Size = New System.Drawing.Size(75, 54)
        Me.botapagar.TabIndex = 1
        Me.botapagar.Text = "<-"
        Me.botapagar.UseVisualStyleBackColor = False
        '
        'botdividir
        '
        Me.botdividir.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.botdividir.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.botdividir.Location = New System.Drawing.Point(255, 141)
        Me.botdividir.Name = "botdividir"
        Me.botdividir.Size = New System.Drawing.Size(75, 55)
        Me.botdividir.TabIndex = 2
        Me.botdividir.Text = "/"
        Me.botdividir.UseVisualStyleBackColor = False
        '
        'botmulti
        '
        Me.botmulti.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.botmulti.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.botmulti.Location = New System.Drawing.Point(255, 202)
        Me.botmulti.Name = "botmulti"
        Me.botmulti.Size = New System.Drawing.Size(75, 55)
        Me.botmulti.TabIndex = 3
        Me.botmulti.Text = "X"
        Me.botmulti.UseVisualStyleBackColor = False
        '
        'botsub
        '
        Me.botsub.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.botsub.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.botsub.Location = New System.Drawing.Point(255, 263)
        Me.botsub.Name = "botsub"
        Me.botsub.Size = New System.Drawing.Size(75, 55)
        Me.botsub.TabIndex = 4
        Me.botsub.Text = "-"
        Me.botsub.UseVisualStyleBackColor = False
        '
        'botsoma
        '
        Me.botsoma.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.botsoma.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.botsoma.Location = New System.Drawing.Point(255, 324)
        Me.botsoma.Name = "botsoma"
        Me.botsoma.Size = New System.Drawing.Size(75, 54)
        Me.botsoma.TabIndex = 5
        Me.botsoma.Text = "+"
        Me.botsoma.UseVisualStyleBackColor = False
        '
        'botresult
        '
        Me.botresult.BackColor = System.Drawing.SystemColors.Highlight
        Me.botresult.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.botresult.Location = New System.Drawing.Point(255, 384)
        Me.botresult.Name = "botresult"
        Me.botresult.Size = New System.Drawing.Size(75, 54)
        Me.botresult.TabIndex = 6
        Me.botresult.Text = "="
        Me.botresult.UseVisualStyleBackColor = False
        '
        'bot0
        '
        Me.bot0.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bot0.Location = New System.Drawing.Point(93, 385)
        Me.bot0.Name = "bot0"
        Me.bot0.Size = New System.Drawing.Size(75, 54)
        Me.bot0.TabIndex = 7
        Me.bot0.Text = "0"
        Me.bot0.UseVisualStyleBackColor = True
        '
        'bot1
        '
        Me.bot1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bot1.Location = New System.Drawing.Point(12, 324)
        Me.bot1.Name = "bot1"
        Me.bot1.Size = New System.Drawing.Size(75, 55)
        Me.bot1.TabIndex = 8
        Me.bot1.Text = "1"
        Me.bot1.UseVisualStyleBackColor = True
        '
        'bot2
        '
        Me.bot2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bot2.Location = New System.Drawing.Point(93, 324)
        Me.bot2.Name = "bot2"
        Me.bot2.Size = New System.Drawing.Size(75, 55)
        Me.bot2.TabIndex = 9
        Me.bot2.Text = "2"
        Me.bot2.UseVisualStyleBackColor = True
        '
        'bot3
        '
        Me.bot3.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bot3.Location = New System.Drawing.Point(174, 324)
        Me.bot3.Name = "bot3"
        Me.bot3.Size = New System.Drawing.Size(75, 55)
        Me.bot3.TabIndex = 10
        Me.bot3.Text = "3"
        Me.bot3.UseVisualStyleBackColor = True
        '
        'bot4
        '
        Me.bot4.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bot4.Location = New System.Drawing.Point(12, 263)
        Me.bot4.Name = "bot4"
        Me.bot4.Size = New System.Drawing.Size(75, 55)
        Me.bot4.TabIndex = 11
        Me.bot4.Text = "4"
        Me.bot4.UseVisualStyleBackColor = True
        '
        'bot5
        '
        Me.bot5.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bot5.Location = New System.Drawing.Point(93, 263)
        Me.bot5.Name = "bot5"
        Me.bot5.Size = New System.Drawing.Size(75, 55)
        Me.bot5.TabIndex = 12
        Me.bot5.Text = "5"
        Me.bot5.UseVisualStyleBackColor = True
        '
        'bot6
        '
        Me.bot6.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bot6.Location = New System.Drawing.Point(174, 263)
        Me.bot6.Name = "bot6"
        Me.bot6.Size = New System.Drawing.Size(75, 55)
        Me.bot6.TabIndex = 13
        Me.bot6.Text = "6"
        Me.bot6.UseVisualStyleBackColor = True
        '
        'bot7
        '
        Me.bot7.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bot7.Location = New System.Drawing.Point(12, 202)
        Me.bot7.Name = "bot7"
        Me.bot7.Size = New System.Drawing.Size(75, 55)
        Me.bot7.TabIndex = 14
        Me.bot7.Text = "7"
        Me.bot7.UseVisualStyleBackColor = True
        '
        'bot8
        '
        Me.bot8.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bot8.Location = New System.Drawing.Point(93, 202)
        Me.bot8.Name = "bot8"
        Me.bot8.Size = New System.Drawing.Size(75, 55)
        Me.bot8.TabIndex = 15
        Me.bot8.Text = "8"
        Me.bot8.UseVisualStyleBackColor = True
        '
        'bot9
        '
        Me.bot9.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bot9.Location = New System.Drawing.Point(174, 202)
        Me.bot9.Name = "bot9"
        Me.bot9.Size = New System.Drawing.Size(75, 55)
        Me.bot9.TabIndex = 16
        Me.bot9.Text = "9"
        Me.bot9.UseVisualStyleBackColor = True
        '
        'Resultado
        '
        Me.Resultado.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Resultado.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Resultado.Location = New System.Drawing.Point(12, 65)
        Me.Resultado.Name = "Resultado"
        Me.Resultado.ReadOnly = True
        Me.Resultado.Size = New System.Drawing.Size(311, 47)
        Me.Resultado.TabIndex = 17
        Me.Resultado.Text = "0"
        Me.Resultado.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextNum1
        '
        Me.TextNum1.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.TextNum1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextNum1.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextNum1.Location = New System.Drawing.Point(12, 24)
        Me.TextNum1.Name = "TextNum1"
        Me.TextNum1.ReadOnly = True
        Me.TextNum1.Size = New System.Drawing.Size(251, 35)
        Me.TextNum1.TabIndex = 18
        Me.TextNum1.Text = "-"
        Me.TextNum1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TxtOp
        '
        Me.TxtOp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtOp.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtOp.Location = New System.Drawing.Point(269, 24)
        Me.TxtOp.Name = "TxtOp"
        Me.TxtOp.ReadOnly = True
        Me.TxtOp.Size = New System.Drawing.Size(54, 35)
        Me.TxtOp.TabIndex = 19
        Me.TxtOp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'botClean
        '
        Me.botClean.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.botClean.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.botClean.Location = New System.Drawing.Point(174, 141)
        Me.botClean.Name = "botClean"
        Me.botClean.Size = New System.Drawing.Size(75, 55)
        Me.botClean.TabIndex = 20
        Me.botClean.Text = "C"
        Me.botClean.UseVisualStyleBackColor = False
        '
        'botInverter
        '
        Me.botInverter.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.botInverter.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.botInverter.Location = New System.Drawing.Point(93, 141)
        Me.botInverter.Name = "botInverter"
        Me.botInverter.Size = New System.Drawing.Size(75, 55)
        Me.botInverter.TabIndex = 21
        Me.botInverter.Text = "+/-"
        Me.botInverter.UseVisualStyleBackColor = False
        '
        'botPonto
        '
        Me.botPonto.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.botPonto.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.botPonto.Location = New System.Drawing.Point(174, 384)
        Me.botPonto.Name = "botPonto"
        Me.botPonto.Size = New System.Drawing.Size(75, 54)
        Me.botPonto.TabIndex = 22
        Me.botPonto.Text = "."
        Me.botPonto.UseVisualStyleBackColor = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(335, 450)
        Me.Controls.Add(Me.botPonto)
        Me.Controls.Add(Me.botInverter)
        Me.Controls.Add(Me.botClean)
        Me.Controls.Add(Me.TxtOp)
        Me.Controls.Add(Me.TextNum1)
        Me.Controls.Add(Me.Resultado)
        Me.Controls.Add(Me.bot9)
        Me.Controls.Add(Me.bot8)
        Me.Controls.Add(Me.bot7)
        Me.Controls.Add(Me.bot6)
        Me.Controls.Add(Me.bot5)
        Me.Controls.Add(Me.bot4)
        Me.Controls.Add(Me.bot3)
        Me.Controls.Add(Me.bot2)
        Me.Controls.Add(Me.bot1)
        Me.Controls.Add(Me.bot0)
        Me.Controls.Add(Me.botresult)
        Me.Controls.Add(Me.botsoma)
        Me.Controls.Add(Me.botsub)
        Me.Controls.Add(Me.botmulti)
        Me.Controls.Add(Me.botdividir)
        Me.Controls.Add(Me.botapagar)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents botapagar As Button
    Friend WithEvents botdividir As Button
    Friend WithEvents botmulti As Button
    Friend WithEvents botsub As Button
    Friend WithEvents botsoma As Button
    Friend WithEvents botresult As Button
    Friend WithEvents bot0 As Button
    Friend WithEvents bot1 As Button
    Friend WithEvents bot2 As Button
    Friend WithEvents bot3 As Button
    Friend WithEvents bot4 As Button
    Friend WithEvents bot5 As Button
    Friend WithEvents bot6 As Button
    Friend WithEvents bot7 As Button
    Friend WithEvents bot8 As Button
    Friend WithEvents bot9 As Button
    Friend WithEvents Resultado As TextBox
    Friend WithEvents TextNum1 As TextBox
    Friend WithEvents TxtOp As TextBox
    Friend WithEvents botClean As Button
    Friend WithEvents botInverter As Button
    Friend WithEvents botPonto As Button
End Class
