﻿Public Class Form1

    Dim op As String
    Dim num1 As Double
    Dim num2 As Double
    Dim res As Double
    Dim textogeral As String
    Dim textoapesquisar As String

    Private Sub ColocarNum(numero As Integer)
        If (Resultado.Text = "0") Then
            Resultado.Text = numero
        Else
            Resultado.Text = Resultado.Text & numero
        End If
    End Sub

    Private Sub bot0_Click(sender As Object, e As EventArgs) Handles bot0.Click
        ColocarNum(0)
    End Sub

    Private Sub bot1_Click(sender As Object, e As EventArgs) Handles bot1.Click
        ColocarNum(1)
    End Sub

    Private Sub bot2_Click(sender As Object, e As EventArgs) Handles bot2.Click
        ColocarNum(2)
    End Sub

    Private Sub bot3_Click(sender As Object, e As EventArgs) Handles bot3.Click
        ColocarNum(3)
    End Sub

    Private Sub bot4_Click(sender As Object, e As EventArgs) Handles bot4.Click
        ColocarNum(4)
    End Sub

    Private Sub bot5_Click(sender As Object, e As EventArgs) Handles bot5.Click
        ColocarNum(5)
    End Sub

    Private Sub bot6_Click(sender As Object, e As EventArgs) Handles bot6.Click
        ColocarNum(6)
    End Sub

    Private Sub bot7_Click(sender As Object, e As EventArgs) Handles bot7.Click
        ColocarNum(7)
    End Sub

    Private Sub bot8_Click(sender As Object, e As EventArgs) Handles bot8.Click
        ColocarNum(8)
    End Sub

    Private Sub bot9_Click(sender As Object, e As EventArgs) Handles bot9.Click
        ColocarNum(9)
    End Sub

    Private Sub botsoma_Click(sender As Object, e As EventArgs) Handles botsoma.Click
        op = "+"
        TxtOp.Text = op
        TextNum1.Text = Resultado.Text
        Resultado.Text = "0"
    End Sub

    Private Sub botsub_Click(sender As Object, e As EventArgs) Handles botsub.Click
        op = "-"
        TxtOp.Text = op
        TextNum1.Text = Resultado.Text
        Resultado.Text = "0"
    End Sub

    Private Sub botmulti_Click(sender As Object, e As EventArgs) Handles botmulti.Click
        op = "X"
        TxtOp.Text = op
        TextNum1.Text = Resultado.Text
        Resultado.Text = "0"
    End Sub

    Private Sub botdividir_Click(sender As Object, e As EventArgs) Handles botdividir.Click
        op = "/"
        TxtOp.Text = op
        TextNum1.Text = Resultado.Text
        Resultado.Text = "0"
    End Sub

    Private Sub botresult_Click(sender As Object, e As EventArgs) Handles botresult.Click
        num1 = TextNum1.Text
        num2 = Resultado.Text

        If op = "+" Then

            res = num1 + num2

        ElseIf op = "-" Then

            res = num1 - num2

        ElseIf op = "X" Then

            res = num1 * num2

        ElseIf op = "/" Then

            res = num1 / num2

        End If

        Resultado.Text = res
        TextNum1.Text = ""
        op = ""
        TxtOp.Text = op
    End Sub

    Private Sub botapagar_Click(sender As Object, e As EventArgs) Handles botapagar.Click
        Resultado.Text = Resultado.Text.Remove(Resultado.Text.Length - 1)
        If (Resultado.Text = "") Then
            Resultado.Text = "0"
        End If
    End Sub

    Private Sub botPonto_Click(sender As Object, e As EventArgs) Handles botPonto.Click
        InStr(textogeral, textoapesquisar)

    End Sub

    Private Sub botClean_Click(sender As Object, e As EventArgs) Handles botClean.Click
        TextNum1.Text = ""
        TxtOp.Text = ""
        Resultado.Text = "0"
    End Sub

    Private Sub botInverter_Click(sender As Object, e As EventArgs) Handles botInverter.Click
        If (Resultado.Text < 0) Then
            Resultado.Text = Resultado.Text * (-1)
        End If
        If (Resultado.Text > 0) Then
            Resultado.Text = Resultado.Text * -1
        End If
    End Sub
End Class
